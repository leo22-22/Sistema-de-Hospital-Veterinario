#include <stdlib.h>
#include <stdio.h>
#include<ctype.h>
#include<string.h>
#include<windows.h>
#include<time.h>
#include <conio.h>
#include "ListaAnimais.h"

struct TpEspecialidade{
	char nome[30];
	TpDescFila fila;
	int atendidos;
	TpEspecialidade *prox, *ant;
};

struct TpDescEsp{
	TpEspecialidade *Inicio, *Fim;
	int Qtde;
};

struct TpAtendente{
	int id, ocupado, TempoRestante, totalAtendidos;
	TpAnimal *animalAtual;
};

//void inicializarEsp(TpDescEsp &D)
//{
//	D.Qtde = 0;
//	D.Inicio = D. Fim = NULL;
//}

//void inicializarFila(TpDescFila &F)
//{
//	F.Qtde = 0;
//	F.Inicio = F.Fim = NULL;
//}

void InserirEsp(TpDescEsp &D)
{
	
	
}

int main()
{
	TpAnimal Animal;
	TpDescFila Fila;
	int Qtde = 0,Tempo = 0;
	FILE *PtrTxt = fopen("Animais.txt","r");
	if(PtrTxt == NULL)
	{
		printf("Hello");
	}
	printf("Digite o Tempo de Execu�ao do programa: \n");
	scanf("%d",&Qtde);
	InicializarFila(Fila);
	fscanf(PtrTxt," %[^;];%d;%[^;];%[^;];%[^;\n]",Animal.prioridade,&Animal.tempoProc,Animal.nome,Animal.data,Animal.especie);
	while(!feof(PtrTxt))
	{
		InserirOrdenadoPrioridade(Fila,Animal);
		fscanf(PtrTxt," %[^;];%d;%[^;];%[^;];%[^;\n]",Animal.prioridade,&Animal.tempoProc,Animal.nome,Animal.data,Animal.especie);
	}
	ExibirFila(Fila);
	
}

